
from importlib.metadata import version

from .geometry import PlanarInductor

__version__ = '0.9.0'
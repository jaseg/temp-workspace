
from importlib.metadata import version

from .geometry import PlanarInductor

__version__ = '0.11.0'